"use strict";
cc._RF.push(module, '3f3f8tG/GpNBrC7Oeiq05kk', 'a');
// scripts/a.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        b: {
            type: dragonBones.ArmatureDisplay,
            default: null
        },
        c: {
            type: dragonBones.ArmatureDisplay,
            default: null
        }
    },
    loadBones: function loadBones(cb) {
        var name = "NewProject";
        var resources = [cc.url.raw("resources/" + name + "_ske.json"), cc.url.raw("resources/" + name + "_atlas.json"), cc.url.raw("resources/" + name + "_tex.png")];

        cc.loader.load(resources, function (err, assets) {
            var factory = dragonBones.CCFactory.getInstance();
            var data = JSON.parse(cc.loader.getRes(resources[0])._dragonBonesJson);
            factory.parseDragonBonesData(data);

            var atlasData = JSON.parse(cc.loader.getRes(resources[1])._atlasJson);
            factory.parseTextureAtlasData(atlasData, cc.loader.getRes(resources[2]));
            console.log(cc.loader.getRes(resources[1])._atlasJson);

            cb && cb();
        });
    },
    start: function start() {
        var _this = this;

        this.loadBones(function () {
            var robotSlot = _this.b.armature().getSlot("fish");
            var factory = dragonBones.CCFactory.getInstance();
            factory.replaceSlotDisplay("NewProject", "Armature", "killboss_bx", "kypy_killboss_mgy", robotSlot);
            _this.b.playAnimation("animation", 500);
        });
        // this.b.playAnimation("animation", 500);   
    }
});

cc._RF.pop();