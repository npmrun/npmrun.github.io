"use strict";
cc._RF.push(module, 'a94a6OY7VJANpwHdRs5/DCs', 'ab');
// scripts/ab.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        b: {
            type: dragonBones.ArmatureDisplay,
            default: null
        },
        c: {
            type: dragonBones.ArmatureDisplay,
            default: null
        }
    },
    start: function start() {
        var robotSlot = this.b.armature().getSlot("fish");
        var factory = dragonBones.CCFactory.getInstance();
        factory.replaceSlotDisplay(this.c.getArmatureKey(), "Armature", "killboss_bx", "kypy_killboss_mgy", robotSlot);
        this.b.playAnimation("animation", 500);
    }
});

cc._RF.pop();