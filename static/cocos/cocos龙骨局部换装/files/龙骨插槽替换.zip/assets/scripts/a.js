cc.Class({
    extends: cc.Component,

    properties: {
        b: {
            type: dragonBones.ArmatureDisplay,
            default: null,
        },
        c: {
            type: dragonBones.ArmatureDisplay,
            default: null,
        }
    },
    loadBones(cb) {
        let name = "NewProject"
        const resources = [
            cc.url.raw(`resources/${name}_ske.json`),
            cc.url.raw(`resources/${name}_atlas.json`),
            cc.url.raw(`resources/${name}_tex.png`),
        ];

        cc.loader.load(resources, (err, assets) => {
            let factory = dragonBones.CCFactory.getInstance();
            let data = JSON.parse(cc.loader.getRes(resources[0])._dragonBonesJson);
            factory.parseDragonBonesData(data);

            let atlasData = JSON.parse(cc.loader.getRes(resources[1])._atlasJson);
            factory.parseTextureAtlasData(atlasData, cc.loader.getRes(resources[2]));
            console.log(cc.loader.getRes(resources[1])._atlasJson);
            
            cb&&cb()
        });
    },
    start () {
        this.loadBones(()=>{
            let robotSlot = this.b.armature().getSlot("fish");
            let factory = dragonBones.CCFactory.getInstance();
            factory.replaceSlotDisplay(
                "NewProject", 
                "Armature", 
                "killboss_bx", 
                "kypy_killboss_mgy", 
                robotSlot
            );
            this.b.playAnimation("animation", 500); 
        })
        // this.b.playAnimation("animation", 500);   
    },
});