cc.Class({
    extends: cc.Component,

    properties: {
        b: {
            type: dragonBones.ArmatureDisplay,
            default: null,
        },
        c: {
            type: dragonBones.ArmatureDisplay,
            default: null,
        }
    },
    start () {
        let robotSlot = this.b.armature().getSlot("fish");
        let factory = dragonBones.CCFactory.getInstance();
        factory.replaceSlotDisplay(
            this.c.getArmatureKey(), 
            "Armature", 
            "killboss_bx", 
            "kypy_killboss_mgy", 
            robotSlot
        );
        this.b.playAnimation("animation", 500);  
    },
});